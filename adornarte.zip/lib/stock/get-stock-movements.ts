import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/auth/get-current-profile";

export async function getStockMovements() {
  const profile =
    await getCurrentProfile();

  if (!profile) {
    throw new Error(
      "Usuario no autenticado"
    );
  }

  const supabase =
    await createClient();

  const { data, error } =
    await supabase
      .from("stock_movements")
      .select(`
        *,
        products (
          name
        ),
        profiles!stock_movements_created_by_fkey (
          full_name
        )
      `)
      .eq(
        "organization_id",
        profile.organization_id
      )
      .order("created_at", {
        ascending: false,
      });

  if (error) {
    throw error;
  }

  return (data ?? []).map(
    (movement) => ({
      ...movement,
      created_at:
        movement.created_at ?? "",
    })
  );
}